public enum ItemCategories
{
    Weapon,
    Armour,
    CurseStone,
    Hybrid,
    Henchmen
}
